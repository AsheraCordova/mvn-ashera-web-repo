//start - license
/*
 * Copyright (c) 2025 Ashera Cordova
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
//end - license
package com.ashera.core;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.teavm.jso.dom.events.Event;
import org.teavm.jso.dom.html.HTMLElement;
import org.teavm.jso.dom.xml.NodeList;

import com.ashera.converter.CommonConverters;
import com.ashera.converter.ConverterFactory;
import com.ashera.core.FragmentManager.FragmentFactory;

import r.android.os.Bundle;

public class FragmentManager {
    public interface Detail extends org.teavm.jso.JSObject {
    	@org.teavm.jso.JSProperty
 	    String getFrom();
 	    
 	    @org.teavm.jso.JSProperty
 	    String getTo();
 	    
 	    @org.teavm.jso.JSProperty
 	    String getSide();
 	    
 	    @org.teavm.jso.JSProperty
	    String getState();
    }
    public interface HistoryEvent extends Event {
    	@org.teavm.jso.JSProperty
    	Detail getDetail();
    }

	private void layoutIfNeeded(GenericFragment genericFragment) {
	}
	
	private Object createDialog() {
		HTMLElement dialog = org.teavm.jso.browser.Window.current().getDocument().createElement("div");
		dialog.setAttribute("dialog", "true");
		dialog.setAttribute("class", "web-dialog");
		return dialog;
	}

	public void closeDialog() {
		HTMLElement shadowRoot = getShadowRoot();
		NodeList<? extends HTMLElement> dialogs = shadowRoot.querySelectorAll(".web-dialog");
		if (dialogs.getLength() > 0) {
			HTMLElement element = dialogs.get(dialogs.getLength() - 1);
			removeChildFromParent(element);
			handleDialogClose(dialogFragments.get(element.getAttribute("fragmentId")));
		}
	}

	private void openDialog(Object dialogObj, int width, int height, String windowCloseOnTouchOutside, Object backdropColor, String backgroundDimEnabled, DialogFragment genericFragment) {
		HTMLElement dialog = (HTMLElement) dialogObj;
		int screenWidth = com.ashera.widget.PluginInvoker.getScreenWidth();
		int screenHeight = com.ashera.widget.PluginInvoker.getScreenHeight();
		dialog.getStyle().setProperty("width", screenWidth + "px");
		dialog.getStyle().setProperty("height", screenHeight + "px");
		dialog.getStyle().setProperty("position", "absolute");
		dialog.setAttribute("fragmentId", genericFragment.getFragmentId());
		
		if (backgroundDimEnabled == null || "true".equals(backgroundDimEnabled)) {
			dialog.getStyle().setProperty("background-color", backdropColor == null ? "#00000033" : (String) backdropColor);
		}
		
		HTMLElement root = updateLeftAndTop(genericFragment, screenWidth, screenHeight);
		dialog.appendChild(root);
		
		HTMLElement currentActiveRoot = getCurrentActiveRoot();
		currentActiveRoot.appendChild(dialog);

		if ("true".equals(windowCloseOnTouchOutside)) {
			dialog.addEventListener("click", (event) -> {
				HTMLElement element = (HTMLElement) event.getTarget().cast();
				if(element.getAttribute("dialog") != null) {
					removeChildFromParent(dialog);
					handleDialogClose(genericFragment);
				}
			});		
		}
	}

	private HTMLElement getCurrentActiveRoot() {
		HTMLElement shadowRoot = getShadowRoot();
		NodeList<? extends HTMLElement> dialogs = shadowRoot.querySelectorAll(".root");
		HTMLElement currentActiveRoot = null;

		for (int i = dialogs.getLength() - 1; i >= 0; i--) {
			currentActiveRoot =  dialogs.get(i);
			
			if (currentActiveRoot.getParentNode() == shadowRoot) {
				break;
			}
		}
		return currentActiveRoot;
	}
	
    @org.teavm.jso.JSBody(params = { "element" }, script = "return element.parentElement;")
    private static native HTMLElement getParentElement(org.teavm.jso.dom.html.HTMLElement element);


	private HTMLElement updateLeftAndTop(DialogFragment genericFragment, int screenWidth, int screenHeight) {
		HTMLElement root = getRoot(genericFragment);
		root.getStyle().setProperty("position", "relative");
		HTMLElement rootWrapper = getParentElement(root);
		if (rootWrapper == null) {
			rootWrapper = org.teavm.jso.browser.Window.current().getDocument().createElement("div");
			rootWrapper.appendChild(root);
		}
		rootWrapper.getStyle().setProperty("position", "absolute");
		rootWrapper.getStyle().setProperty("width", "max-content");
		rootWrapper.getStyle().setProperty("height", "max-content");
		r.android.view.View view = (r.android.view.View)genericFragment.getRootWidget().asWidget();
		rootWrapper.getStyle().setProperty("left", (screenWidth - view.getMeasuredWidth()) /2 + "");
		rootWrapper.getStyle().setProperty("top", (screenHeight - view.getMeasuredHeight()) /2 + "");
		
		return rootWrapper;
	}

	private void deactivateCurrentFragment(GenericFragment activeFragment) {
		getRoot(activeFragment).getStyle().setProperty("visibility", "hidden");
	}

	private void disposeRoot(GenericFragment fragmentToBeDisposed) {
		if (rootHTMLElement != null) {
			rootHTMLElement.removeChild(getRoot(fragmentToBeDisposed));
		} else {
			removeChildFromShadowRoot(getRoot(fragmentToBeDisposed));
		}
	}	
	
	private void removeChildFromParent(HTMLElement element) {
		element.getParentNode().removeChild(element);
	}


	private void addRootToView(GenericFragment genericFragment) {
		if (rootHTMLElement != null) {
			rootHTMLElement.appendChild(getRoot(genericFragment));
		} else {
			appendChildToShadowRoot(getRoot(genericFragment));
		}
	}

	private HTMLElement getRoot(GenericFragment fragment) {
		return (HTMLElement) fragment.getRootWidget().asNativeWidget();
	}

    public FragmentManager(IActivity activity) {
        this.activity = activity;
        this.disableHistory = "true".equals(activity.getPreference("webDisableHistory"));
        this.historyUrlPrefix = activity.getPreference("webHistoryUrlPrefix");
        
        if (this.historyUrlPrefix == null) {
        	this.historyUrlPrefix = "";
        }
        addHistoryChangeEvent();
        this.fragmentFactory = new FragmentFactory();
    }
    
    public FragmentManager(IActivity activity, HTMLElement rootHTMLElement, FragmentFactory fragmentFactory) {
        this.activity = activity;
        this.disableHistory = true;
        this.historyUrlPrefix = activity.getPreference("webHistoryUrlPrefix");
        
        if (this.historyUrlPrefix == null) {
        	this.historyUrlPrefix = "";
        }
        addHistoryChangeEvent();
        this.fragmentFactory = fragmentFactory;
        this.rootHTMLElement = rootHTMLElement;
    }
    
    private HTMLElement rootHTMLElement;
    // history related methods - starts here
    private boolean disableHistory;
    private String historyUrlPrefix;
	private final class HistoryChangeListener implements org.teavm.jso.dom.events.EventListener<HistoryEvent> {
		private final IAsyncCallBack callback;

		private HistoryChangeListener(IAsyncCallBack callback) {
			this.callback = callback;
		}

		@Override
		public void handleEvent(HistoryEvent evt) {
			org.teavm.jso.browser.Window.current().removeEventListener("historyChange", this);
			com.ashera.widget.PluginInvoker.postDelayed(() -> callback.done(), 30);
		}
	}
	private void addHistoryChangeEvent() {
		if (!disableHistory) {
			org.teavm.jso.browser.Window.current().addEventListener("historyChange", new org.teavm.jso.dom.events.EventListener<HistoryEvent>() {
	
				@Override
				public void handleEvent(HistoryEvent evt) {
					if (evt.getDetail().getSide().equals("back")) {
						handleBackChange(evt);
					} else {
						java.util.HashMap<String, String> obj = com.ashera.widget.PluginInvoker.unmarshal(evt.getDetail().getState(), java.util.HashMap.class);
						Object payload = com.ashera.widget.PluginInvoker.unmarshal(obj.get("payload"), List.class);
						navigate("fragment", obj.get("resId"), obj.get("fileName"), obj.get("manager"), (List<Map<String, Object>>) payload, false);
					}
					
				}
	        });
		}
	}

	private void storeInHistory(String type, String resId, String fileName, String manager, List<Map<String, Object>> scopedObjects) {
		if (!disableHistory) {
			if (manager == null) {
				manager = "";
			}
			String historyUrl = fileName.substring(fileName.lastIndexOf("/"));
	    	String data = String.format("{\"resId\": \"%s\", \"fileName\": \"%s\", \"manager\": \"%s\", \"payload\": \"%s\"}", resId,
	    			fileName, manager, escape(com.ashera.widget.PluginInvoker.marshal(scopedObjects)));
			org.teavm.jso.JSObject obj = org.teavm.jso.json.JSON.parse(data);
			org.teavm.jso.browser.Window.current().getHistory().pushState(obj, "", historyUrlPrefix + historyUrl.replace(".xml", ""));
		}
	}
	
	public void popBackStack(IAsyncCallBack callback) {
		if (disableHistory) {
			pop();	
		} else {
			org.teavm.jso.browser.Window.current().addEventListener("historyChange", new HistoryChangeListener(callback));
			org.teavm.jso.browser.Window.current().getHistory().go(-1);	
		}
	}
	
	public void popBackStack(String destinationId, boolean inclusive, IAsyncCallBack callback) {
		try {
			if (disableHistory) {
				popBackStack(destinationId, inclusive, 1);
				callback.done();
			} else {
				int popCount = getPopCounter(destinationId, inclusive, 1);
				org.teavm.jso.browser.Window.current().addEventListener("historyChange", new HistoryChangeListener(callback));
				for (int i = 0; i < popCount; i++) {
					org.teavm.jso.browser.Window.current().getHistory().go(-1);
				}
			}
			makeCurrentFragmentActive();
		} catch (DestinatinNotFoundException e) {
			System.out.println(e.getMessage());
		}

	}
	
	// history related methods - starts here

	private boolean activateCurrentFragment(GenericFragment activeFragment) {
		getRoot(activeFragment).getStyle().setProperty("visibility", "visible");
		return true;
	}

	private void handleBackChange(HistoryEvent evt) {
		try {
			String state = "{\"fileName\" : \"layout/index.xml\"}";
			
			try {
				state = evt.getDetail().getState();
			} catch (Exception e) {
			}
			java.util.HashMap<String, String> obj = com.ashera.widget.PluginInvoker.unmarshal(state, java.util.HashMap.class);
			String actionUrl = null;
			if (fragments.size() - 2 >= 0) {
				actionUrl = fragments.get(fragments.size() - 2).getActionUrl();
			}
			
			if (!this.historyUrlPrefix.equals("")) {
				actionUrl = actionUrl.replaceFirst(this.historyUrlPrefix, "");
			}
			if (obj.get("fileName").equals(actionUrl)) {
				pop();	
			} else {
				org.teavm.jso.browser.Window.current().getHistory().go(-1);							
			}
			
		} catch (Exception e) {
			// ignore
			org.teavm.jso.browser.Window.current().getHistory().go(-1);
		}
	}

	private static String escape(String jsString) {
	    jsString = jsString.replace("\\", "\\\\");
	    jsString = jsString.replace("\"", "\\\"");
	    jsString = jsString.replace("\b", "\\b");
	    jsString = jsString.replace("\f", "\\f");
	    jsString = jsString.replace("\n", "\\n");
	    jsString = jsString.replace("\r", "\\r");
	    jsString = jsString.replace("\t", "\\t");
	    jsString = jsString.replace("/", "\\/");
	    return jsString;
	}

	@org.teavm.jso.JSBody(params = { "element" }, script = "window.shadowRoot.appendChild(element);")
    private static native void appendChildToShadowRoot(org.teavm.jso.dom.html.HTMLElement element);
	
	@org.teavm.jso.JSBody(params = { "element" }, script = "window.shadowRoot.removeChild(element);")
    private static native void removeChildFromShadowRoot(org.teavm.jso.dom.html.HTMLElement element);
	
	@org.teavm.jso.JSBody(params = {}, script = "return window.shadowRoot;")
    private static native HTMLElement getShadowRoot();
	//start - navigator
	private String namespace;
	private String rootDirectory;
	private List<GenericFragment> fragments = new ArrayList<>();
	private static Map<String, DialogFragment> dialogFragments = new LinkedHashMap<>();
	private IActivity activity;
	private FragmentFactory fragmentFactory;
	private boolean remeasure = true;
	
	
	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}

	public void setRootDirectory(String rootDirectory) {
		this.rootDirectory = rootDirectory;
	}
	
	private void popBackStack(String destinationId, boolean inclusive, int indexFromEnd)
			throws DestinatinNotFoundException {
		int popCount = getPopCounter(destinationId, inclusive, indexFromEnd);

		for (int i = 0; i < popCount; i++) {
			pop(indexFromEnd);
		}
	}

	private void pop() {
		if (fragments.size() > 1) {
			pop(1);
			makeCurrentFragmentActive();
		}
	}

	private void makeCurrentFragmentActive() {
		GenericFragment activeFragment = getActiveFragment();
		
		if (activateCurrentFragment(activeFragment)) {
			activeFragment.remeasure();
		}
		activeFragment.onResume();
	}

	private void pop(int indexFromEnd) {
		GenericFragment fragmentToBeDisposed = fragments.get(fragments.size() - indexFromEnd);
		fragmentToBeDisposed.onPause();

		disposeRoot(fragmentToBeDisposed);

		fragmentToBeDisposed.onDestroy();
		fragmentToBeDisposed.onDetach();

		fragments.remove(fragments.size() - indexFromEnd);
	}

	public GenericFragment getActiveFragment() {
		if (dialogFragments.size() > 0) {
			Entry<String, DialogFragment> lastEntry = getLastDialogEntry();
			return lastEntry.getValue();
		}
		return fragments.get(fragments.size() - 1);
	}

	private Entry<String, DialogFragment> getLastDialogEntry() {
		List<Entry<String, DialogFragment>> entryList = new ArrayList<>(dialogFragments.entrySet());
		Entry<String, DialogFragment> lastEntry = entryList.get(entryList.size() - 1);
		return lastEntry;
	}
	

	public void navigate(String resId, String fileName) {
		navigate("fragment", resId, fileName, null, null, true);
	}

	private void navigate(String type, String resId, String fileName, String manager, 
			List<Map<String, Object>> scopedObjects, boolean history) {
		//onpause
		onPause();
		
		if (fragments.size() > 0) {
			deactivateCurrentFragment(getActiveFragment());
			if (history) {
				storeInHistory(type, resId, fileName, manager, scopedObjects);
			}
		}
		
		GenericFragment genericFragment = this.fragmentFactory.getFragment();

		
		//oncreate
		onCreate(resId, fileName, manager, scopedObjects, genericFragment);
		
		//oncreateview
		genericFragment.onCreateView(this.remeasure);
		
		fragments.add(genericFragment);
		addRootToView(genericFragment);
		
		//onresume
		layoutIfNeeded(genericFragment);
		genericFragment.onResume();
	}


	public void navigate(String actionId, String destinationId, boolean inclusive, boolean finish, List<Map<String, Object>> scopedObjects, IFragment fragment) {
		navigate(actionId, scopedObjects, fragment);
		
		if (finish) {
			try {
				String id = ((r.android.os.Bundle) fragments.get(0).getArgumentsBundle()).getString("id");
				popBackStack(id, true, 2);
			} catch (DestinatinNotFoundException e) {
				System.out.println(e.getMessage());
			}
		} else if (destinationId != null) {
			try {
				popBackStack(destinationId, inclusive, 2);
			} catch (DestinatinNotFoundException e) {
				System.out.println(e.getMessage());
			}
		} else if (inclusive) {
			pop(2);
		}
	}
	
	public void navigate(String actionId, List<Map<String, Object>> scopedObjects, IFragment fragment) {
		String[] destinationProps = actionId.split("#", -1);
		String[] typeAndManager = destinationProps[0].split("~");
		String type = typeAndManager[0];
		String manager = typeAndManager.length > 1 ? typeAndManager[1] : null;

		String resId = destinationProps[1];
		switch (type) {
		case "dialog": {
			String fileName = getFileName(destinationProps, 3);
			int width = (int) ConverterFactory.get(CommonConverters.dimension).convertFrom(destinationProps[destinationProps.length - 3], null, fragment);
			int height = (int) ConverterFactory.get(CommonConverters.dimension).convertFrom(destinationProps[destinationProps.length - 2], null, fragment);
			String style = destinationProps[destinationProps.length - 1];
			if (style != null) {
				style = style.replace("@style/", "");
			}
			String attrStr = com.ashera.utils.ResourceBundleUtils.getString("values/theme", style.replace("@style/", ""), fragment);
			Object backdropColor = null;
			Float marginPercent = null;
			String windowCloseOnTouchOutside = null;
			String backgroundDimEnabled = null;
			if (attrStr != null && !attrStr.isEmpty()) {
		        String[] attrs = attrStr.split(";");
		        for (String attr : attrs) {
		        	String[] nameAndValue = attr.split("\\:");
		        	String key = nameAndValue[0];
		        	String value = nameAndValue.length <= 1 ? "" : nameAndValue[1];
		        	
		        	if (key.equals("marginPercent")) {
		        		marginPercent = (Float) ConverterFactory.get(CommonConverters.floatconverter).convertFrom(value, null, fragment);
		        	}
		        	if (key.equals("backdropColor")) {
		        		backdropColor = ConverterFactory.get("color").convertFrom(value, null, fragment);
		        	}
		        	if (key.equals("windowCloseOnTouchOutside")) {
		        		windowCloseOnTouchOutside = value;
		        	}
		        	
		        	if (key.equals("backgroundDimEnabled")) {
		        		backgroundDimEnabled = value;
		        	}
		        }
			}
			navigateToDialog(type, resId, fileName, width, height, windowCloseOnTouchOutside, backdropColor, backgroundDimEnabled, marginPercent, manager, scopedObjects);
			break;
		}
		default: {
			String fileName = getFileName(destinationProps, 0);
			navigate(type, resId, fileName, manager, scopedObjects, true);
			break;
		}
		}
	}

	private String getFileName(String[] destinationProps, int noofProps) {
		String fileName = "";
		String separator = "";

		for (int i = 2; i < destinationProps.length - noofProps; i++) {
			String destinationProp = destinationProps[i];
			fileName += separator +destinationProp;
			separator = "#";
		}
		return fileName;
	}
	

	private void navigateToDialog(String type, String resId, String fileName,
			int width, int height, String windowCloseOnTouchOutside, Object backdropColor, String backgroundDimEnabled, Float marginPercent, String managers, List<Map<String, Object>> scopedObjects) {
		//onpause

		Object dialog = createDialog();

		DialogFragment genericFragment = fragmentFactory.getDialogFragment(this, dialog, width, height, marginPercent);
		
		if (genericFragment.isFullScreen()) {
			onPause();
		}
		
		//oncreate
		onCreate(resId, fileName, managers, scopedObjects, genericFragment);
		dialogFragments.put(genericFragment.getFragmentId(), genericFragment);
		
		//oncreateview for dialog
		genericFragment.onCreateView(true);

		openDialog(dialog, width, height, windowCloseOnTouchOutside, backdropColor, backgroundDimEnabled,  genericFragment);

		//onresume
		layoutIfNeeded(genericFragment);
		genericFragment.onResume();
	}
	
	private void onCreate(String resId, String fileName, String fragmentManagers, List<Map<String, Object>> scopedObjects,
			GenericFragment genericFragment) {
		Bundle bundle = GenericFragment.getInitialBundle(resId, fileName, fragmentManagers, scopedObjects);
		bundle.putString("rootDirectory", rootDirectory);
		bundle.putString("namespace", namespace);
		genericFragment.setArguments(bundle);
		genericFragment.onAttach(activity);
		genericFragment.onCreate();
	}

	private void onPause() {
		if (fragments.size() > 0) {
			GenericFragment activeFragment = getActiveFragment();
			if (activeFragment != null) {
				activeFragment.onPause();
			}
		}
	}

	private void handleResize(DialogFragment dialogFragment, int maxWidth, int maxHeight) {
		dialogFragment.setMaxWidth(maxWidth);
		dialogFragment.setMaxHeight(maxHeight);
		dialogFragment.remeasure();
	}
	

	private void handleDialogClose(DialogFragment dialogFragment) {
		dialogFragment.onPause();
		dialogFragment.onDestroy();
		dialogFragment.onDetach();
		dialogFragments.remove(dialogFragment.getFragmentId());
		
		GenericFragment fragment = getActiveFragment();
		if (dialogFragment.isFullScreen()) {
			fragment.onResume();
		}
		java.util.Map<String, String> eventData = new java.util.HashMap<>();
		eventData.put("dialogClosed", dialogFragment.getActionUrl());
		fragment.onCloseDialog(eventData);
	}

	private int getPopCounter(String destinationId, boolean inclusive, int indexFromEnd)
			throws DestinatinNotFoundException {
		boolean foundDestination = false;
		int popCount = 0;
		for (int i = fragments.size() - indexFromEnd; i >= 0; i--) {
			GenericFragment genericFragment = fragments.get(i);
			String id = ((r.android.os.Bundle) genericFragment.getArgumentsBundle()).getString("id");
			if (id.equals(destinationId)) {
				foundDestination = true;
				if (inclusive) {
					popCount++;
				}
				break;
			}
			popCount++;
		}

		if (!foundDestination) {
			// We were passed a destinationId that doesn't exist on our back stack.
			// Better to ignore the popBackStack than accidentally popping the entire stack
			throw new DestinatinNotFoundException("Ignoring popBackStack to destination " + destinationId
					+ " as it was not found on the current back stack");
		}
		return popCount;
	}
	
	class DestinatinNotFoundException extends Exception {
		public DestinatinNotFoundException(String message) {
			super(message);
		}
	}
	
	public static class FragmentFactory {
		public GenericFragment getFragment() {
			return new GenericFragment() {
				@Override
				public void createChildFragments() {
					executePendingTransactions();
				}
			};
		}
		
		public DialogFragment getDialogFragment(FragmentManager fragmentManager, Object dialog, int width, int height, Float marginPercent) {
			return new DialogFragment(dialog, width, height, marginPercent) {
				@Override
				public void remeasure() {
					super.remeasure();
					if (!isMeasuring()) {
						if (getRootWidget() != null) {
							// update size of dialog
							fragmentManager.updateSizeIfRequired(this);
						}
					}
					
				}
			};
		}
	}

	//end - navigator
	

	private void updateSizeIfRequired(DialogFragment dialogFragment) {
		int screenWidth = com.ashera.widget.PluginInvoker.getScreenWidth();
		int screenHeight = com.ashera.widget.PluginInvoker.getScreenHeight();

		updateLeftAndTop(dialogFragment, screenWidth, screenHeight);		
	}
}